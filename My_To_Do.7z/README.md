### 앱소개

이번주 날씨와 이번주 할일을 관리하는 모바일/웹 어플리케이션

## Useage

## 필수
- Node v20.11.1 이상
- git

## 실행순서
1. `npm i` : 패키지 설치
2. `npm run server` : JSON server 구동 [http://localhost:3004](http://localhost:3004)
3. `npm start` : devmode app 구동 [http://localhost:3000](http://localhost:3000)

